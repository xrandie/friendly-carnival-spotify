import styled from 'styled-components/macro';

const Nav = styled.nav`
  margin: 0;
`;

export default Nav;
